export type FuseDrawerMode =
    | 'over'
    | 'side';

export type FuseDrawerPosition =
    | 'left'
    | 'right';
