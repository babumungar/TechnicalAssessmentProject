import { Injectable } from '@angular/core';
import { User } from 'app/core/user/user.types';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  
  constructor() { }
}
