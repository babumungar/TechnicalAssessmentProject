import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-assessment-details-page',
  templateUrl: './assessment-details-page.component.html',
  styleUrls: ['./assessment-details-page.component.scss']
})
export class AssessmentDetailsPageComponent implements OnInit {
  assessmentForm: FormGroup;
  javaRating: any;
  angularRating: any;
  mysqlRating: any;
  reactRating: any;
  selectedStatus: any;
  duration: any;
  overallRating: any;

  fields = [
    {label: 'Java', name: 'javaRating'},
    {label: 'Angular', name: 'angularRating'},
    {label: 'MySQL', name: 'mysqlRating'},
    {label: 'React', name: 'reactRating'}
  ];


  constructor(private fb: FormBuilder, private router: Router) { }

  closeDialog() {
    alert("Form submitted successfully");

    this.router.navigate(['main'])
  }
  ngOnInit(): void {
    // this.assessmentForm = this.formBuilder.group({
    //   interviewRound: ['', Validators.required],
    //   interviewMode: ['', Validators.required],
    //   duration: ['', Validators.required],
    //   technologies: ['', Validators.required],
    //   overallRating: [''],
    //   interviewStatus: ['']
    // });
    this.assessmentForm = new FormGroup({

      duration: new FormControl(null, [Validators.required]),
      javaRating: new FormControl(null, [Validators.required]),
      angularRating: new FormControl(null, [Validators.required]),
      mysqlRating: new FormControl(null, [Validators.required]),
      reactRating: new FormControl(null, [Validators.required]),
      overallRating: new FormControl(null, [Validators.required]),
      selectedStatus: new FormControl(null, [Validators.required]),
    });

  }

 
}
