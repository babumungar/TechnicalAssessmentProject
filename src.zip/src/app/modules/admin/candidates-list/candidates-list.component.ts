import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ShowCandidateComponent } from 'app/src/app/modules/admin/show-candidate/show-candidate.component';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { UserComponent } from 'app/layout/common/user/user.component';
import { Router } from '@angular/router';
import { CandidateFormComponent } from '../candidate-form/candidate-form.component';


export interface PeriodicElement {
  first_name: string;
  last_name: string;

  id: number;
  mail: string;
  mobile:number;
  interviewer:string;
  date:string;
  time:string;
}
export interface DialogDataUserId {
  userObj: any

}
const ELEMENT_DATA: PeriodicElement[] = [
  { id: 1, first_name: 'Subhash', last_name: 'mungara', mail: "kumar@gmail.com", mobile: 24535353556, interviewer: "sameer", date: "2023-04-28", time: "10:30 AM" },
  { id: 2, first_name: 'Subhashish', last_name: 'sanjay', mail: "babu@gmail.com", mobile: 24535353556, interviewer: "sk", date: "2023-04-29", time: "2:00 PM" },
  { id: 3, first_name: 'Trishore', last_name: 'baji', mail: "trishore@gmail.com", mobile: 24535353556, interviewer: "jason", date: "2023-05-01", time: "11:00 AM" },
  { id: 4, first_name: 'Swamy', last_name: 'sudhabattula', mail: "Steve@gmail.com", mobile: 24535353556, interviewer: "sameer", date: "2023-05-02", time: "3:30 PM" },
  { id: 5, first_name: 'Narendra', last_name: 'medisetti', mail: "Rogers@gmail.com", mobile: 24535353556, interviewer: "sk", date: "2023-05-03", time: "10:00 AM" },
  { id: 6, first_name: 'steve', last_name: 'rogers', mail: "Tony@gmail.com", mobile: 24535353556, interviewer: "jason", date: "2023-05-04", time: "1:30 PM" },
  { id: 7, first_name: 'Tony', last_name: 'stark', mail: "Stark@gmail.com", mobile: 24535353556, interviewer: "sk", date: "2023-05-05", time: "4:00 PM" },
];

//const dataSource = new MatTableDataSource<PeriodicElement>([]);


@Component({
  selector: 'app-candidates-list',
  templateUrl: './candidates-list.component.html',
  styleUrls: ['./candidates-list.component.scss']
})



export class CandidatesListComponent implements OnInit {
  isHr:boolean = true;
  isInterviwer:boolean = false;

  [x: string]: any;
  displayedColumns: string[] = ['id','first_name', 'last_name', 'mail','mobile','interviewer','date', 'time',  'actions', 'report'];
  //dataSource = ELEMENT_DATA;
  clickedRows = new Set<PeriodicElement>();
  dataSource: any;
  // @ViewChild(MatPaginator) paginator!: MatPaginator;
  searchText = '';

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(public dialog: MatDialog, private router: Router) { 
    if (this.isHr) {
      //this.displayedColumns.splice(this.displayedColumns.indexOf('report'), 1);
    }
    if (this.isInterviwer) {
      this.displayedColumns.splice(this.displayedColumns.indexOf('actions'), 1);
    }
  }

  onSubmit() {
    this.filterData(this.searchText);

  }

  ngOnInit(): void {
    this.dataSource = new MatTableDataSource(ELEMENT_DATA);
    setTimeout(() => this.dataSource.paginator = this.paginator, 0)
  }

  showCandidate() {
    //console.log("fg")
    this.router.navigate(['show-candidate']);
  }

  reportButton(){
    this.router.navigate(['assessment-details-page']);
  }



  editCandidate() {

    this.router.navigate(['edit-candidate']);

  }

  deleteCandidate(id: number) {
    const index = this.dataSource.data.findIndex((element: PeriodicElement) => element.id === id);
    if (index >= 0) {
      this.dataSource.data.splice(index, 1);
      this.dataSource = new MatTableDataSource(this.dataSource.data);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
    }
  }
  filterData(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }


}
